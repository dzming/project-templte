import Vue from "vue";
import VueRouter from "vue-router";
import { Route } from "vue-router";
import { ElLoading } from "element-ui/types/loading";
import { ElMessage } from "element-ui/types/message";
import { ElMessageBox } from "element-ui/types/message-box";
import { ElNotification } from "element-ui/types/notification";
// 扩充
declare module "vue/types/vue" {
  interface Vue {
    $router: VueRouter;
    $route: Route;
    $http: any;
    $style: { [key: string]: string }
    // $loading: any;
    // $alert: any;
    // $confirm: any;
    $message: ElMessage;
    $msgbox: ElMessageBox;
    $notify: ElNotification;
    // $prompt: any;
  }
}
