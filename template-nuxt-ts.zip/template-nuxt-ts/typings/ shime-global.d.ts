declare var window: Window & typeof globalThis;
declare var document: Document;
