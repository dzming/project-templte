// import { DELETE, GET, POST, PUT } from '@/utils/request';

// // 登录
// export function login({ telephone }: { telephone: string }) {
//   return POST('/user/login', {
//     telephone
//   });
// }

import * as user from "./modules/user";

export {
  user
}