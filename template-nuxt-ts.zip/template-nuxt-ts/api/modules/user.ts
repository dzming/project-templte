import { $axios } from "@/utils/request";

export function getUserInfo() {
  return $axios.get("/userinfo");
}

