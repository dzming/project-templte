import Vue from "vue";
import Element from "element-ui";
// import "~/styles/settings/element-variables.scss";
// import Element from 'element-ui/lib';
// import locale from 'element-ui/lib/locale/lang/en'
// import '~/styles/settings/theme/index.css';



export default () => {
  // Vue.use(Element, { locale })
  Vue.use(Element);
};

